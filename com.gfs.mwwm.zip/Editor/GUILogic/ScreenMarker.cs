﻿using System;

namespace UISystem.GUILogic
{
    /// <summary>
    /// Помечает поле как поле хранящее ссылку на префаб скрина
    /// </summary>
    public class ScreenMarker : Attribute
    {
    }
}